# Deployment Instructions for Zyron Semiconductors

This document provides instructions for deploying the frontend and backend separately to your domains:
- Frontend: `zyronsemiconductors.com`
- Backend: `server.zyronsemiconductors.com`

## Frontend Deployment

### Prerequisites
- Vercel account
- GitHub account
- Domain: `zyronsemiconductors.com`

### Steps
1. Create a new repository named `zyron_frontend`
2. Copy the contents of the `frontend` directory to this repository
3. Push the code to GitHub
4. Import the project to Vercel
5. Configure environment variables in Vercel dashboard:
   - `VITE_API_BASE_URL`: `https://server.zyronsemiconductors.com`
   - `VITE_SUPABASE_URL`: Your Supabase project URL
   - `VITE_SUPABASE_PUBLISHABLE_DEFAULT_KEY`: Your Supabase anon key
6. Add the custom domain `zyronsemiconductors.com` in Vercel dashboard
7. Update your DNS settings as per Vercel's instructions

## Backend Deployment

### Prerequisites
- Vercel account
- GitHub account
- Domain: `server.zyronsemiconductors.com`

### Steps
1. Create a new repository named `zyron_backend`
2. Copy the contents of the `backend` directory to this repository
3. Push the code to GitHub
4. Import the project to Vercel
5. Configure environment variables in Vercel dashboard:
   - `VITE_SUPABASE_URL`: Your Supabase project URL
   - `VITE_SUPABASE_PUBLISHABLE_DEFAULT_KEY`: Your Supabase anon key
   - `VITE_SUPABASE_SERVICE_ROLE_KEY`: Your Supabase service role key
   - `DATABASE_URL`: Your database connection string
   - `CLOUDINARY_URL`: Your Cloudinary URL
   - `EMAIL_USER`: Your email address
   - `EMAIL_PASS`: Your email app password
   - `CLIENT_URL`: `https://zyronsemiconductors.com`
6. Add the custom domain `server.zyronsemiconductors.com` in Vercel dashboard
7. Update your DNS settings as per Vercel's instructions

## Required Services

### Supabase Setup
- Ensure your Supabase project is properly configured with the required tables
- Run the SQL from `supabase/migrations/01_create_tables.sql` in your Supabase SQL editor

### Cloudinary Setup
- Create a Cloudinary account
- Configure your Cloudinary URL in the format: `cloudinary://api_key:api_secret@cloud_name`

### Email Setup
- For Gmail, use an App Password (not your regular password)
- To get an App Password:
  1. Enable 2-Factor Authentication on your Google account
  2. Go to Google Account settings -> Security -> App passwords
  3. Generate a new app password for 'Mail'
  4. Use that 16-character password

## Environment Variables

### Frontend Environment Variables (.env.production)
```
VITE_API_BASE_URL=https://server.zyronsemiconductors.com
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_PUBLISHABLE_DEFAULT_KEY=your_supabase_anon_key
```

### Backend Environment Variables (.env.production)
```
# Server Configuration
PORT=5000

# Supabase Configuration
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_PUBLISHABLE_DEFAULT_KEY=your_supabase_anon_key
VITE_SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
DATABASE_URL=your_database_url

# Cloudinary Configuration
CLOUDINARY_URL=your_cloudinary_url

# Email Configuration
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_app_password

# Client URL (Frontend domain)
CLIENT_URL=https://zyronsemiconductors.com

# Admin Password
ADMIN_PASSWORD=your_secure_admin_password
```

## Verification Steps

1. Visit `https://zyronsemiconductors.com` to ensure the frontend loads correctly
2. Test the backend health check at `https://server.zyronsemiconductors.com/api`
3. Submit a form on the frontend to ensure it can communicate with the backend
4. Verify that data is properly stored in Supabase

## Troubleshooting

### CORS Issues
- Ensure `CLIENT_URL` in backend environment variables matches your frontend domain
- Check that the domain is properly configured in both frontend and backend

### API Connection Issues
- Verify that `VITE_API_BASE_URL` in frontend points to your backend domain
- Check that both domains are properly configured and accessible

### Email Issues
- Verify that email credentials are correctly set
- Ensure you're using an App Password for Gmail, not your regular password